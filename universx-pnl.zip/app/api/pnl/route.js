import { fetchPnL } from "../../../lib/pnl.js";

export async function POST(req) {
  try {
    const body = await req.json();
    const wallet = String(body.wallet || "").trim();
    const mint = String(body.mint || "").trim();

    if (!wallet || !mint) {
      return Response.json({ error: "wallet と mint は必須です" }, { status: 400 });
    }

    const data = await fetchPnL({ wallet, mint });
    return Response.json(data, { status: 200 });
  } catch (err) {
    const message = err?.message || "Server error";
    return Response.json({ error: message }, { status: 500 });
  }
}
