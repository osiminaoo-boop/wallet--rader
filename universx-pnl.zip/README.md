# UniversalX PnL calculator

Solscan の `account/balance_change` を使って、指定ウォレットが特定トークンでいくら増減したかをざっくり計算する Next.js アプリです。

## 使い方

1. `npm install`
2. `.env.local` に `SOLSCAN_API_KEY=...` を入れる
3. `npm run dev`

## 入力
- Wallet address
- Token CA

## 仕組み
- `account/balance_change` で対象トークンと SOL の残高変化を取得
- 同じ `trans_id` でペアにして売買を推定
- FIFO で realized PnL を計算

## 注意
- 送金、エアドロップ、LP追加/解除、ブリッジ系は誤判定することがあります
- Solscan Pro API のキーが必要です
