export const metadata = {
  title: "UniversalX PnL calculator",
  description: "Calculate token PnL for a Solana wallet using Solscan"
};

export default function RootLayout({ children }) {
  return (
    <html lang="ja">
      <body style={{ margin: 0, fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif", background: "#0b1020", color: "#e8ecf8" }}>
        {children}
      </body>
    </html>
  );
}
