use client';

import { useMemo, useState } from "react";

function fmt(n, digits = 4) {
  if (n === null || n === undefined || Number.isNaN(Number(n))) return "-";
  const x = Number(n);
  return x.toLocaleString("en-US", { maximumFractionDigits: digits, minimumFractionDigits: 0 });
}

function StatCard({ label, value, sub }) {
  return (
    <div style={{
      border: "1px solid rgba(255,255,255,0.12)",
      borderRadius: 16,
      padding: 16,
      background: "rgba(255,255,255,0.04)",
      minWidth: 180
    }}>
      <div style={{ fontSize: 12, opacity: 0.8, marginBottom: 8 }}>{label}</div>
      <div style={{ fontSize: 24, fontWeight: 700 }}>{value}</div>
      {sub ? <div style={{ marginTop: 6, fontSize: 12, opacity: 0.75 }}>{sub}</div> : null}
    </div>
  );
}

export default function Page() {
  const [wallet, setWallet] = useState("");
  const [mint, setMint] = useState("");
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const summary = useMemo(() => {
    if (!result) return null;
    return result.summary;
  }, [result]);

  async function onSubmit(e) {
    e.preventDefault();
    setError("");
    setResult(null);
    setLoading(true);
    try {
      const res = await fetch("/api/pnl", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ wallet, mint })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data?.error || "計算に失敗しました");
      }
      setResult(data);
    } catch (err) {
      setError(err.message || "不明なエラー");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main style={{ maxWidth: 1100, margin: "0 auto", padding: "32px 20px 60px" }}>
      <h1 style={{ fontSize: 30, margin: "0 0 8px" }}>UniversalX PnL calculator</h1>
      <p style={{ margin: "0 0 24px", opacity: 0.82, lineHeight: 1.6 }}>
        Solscan の残高変化から、指定ウォレットの対象コイン損益を計算します。
      </p>

      <form onSubmit={onSubmit} style={{
        display: "grid",
        gap: 12,
        gridTemplateColumns: "1fr 1fr auto",
        alignItems: "end",
        padding: 18,
        borderRadius: 18,
        border: "1px solid rgba(255,255,255,0.12)",
        background: "rgba(255,255,255,0.03)"
      }}>
        <label style={{ display: "grid", gap: 8 }}>
          <span style={{ fontSize: 13, opacity: 0.8 }}>Wallet address</span>
          <input
            value={wallet}
            onChange={(e) => setWallet(e.target.value.trim())}
            placeholder="Solana wallet address"
            style={inputStyle}
          />
        </label>
        <label style={{ display: "grid", gap: 8 }}>
          <span style={{ fontSize: 13, opacity: 0.8 }}>Token CA</span>
          <input
            value={mint}
            onChange={(e) => setMint(e.target.value.trim())}
            placeholder="Token mint address"
            style={inputStyle}
          />
        </label>
        <button
          disabled={loading || !wallet || !mint}
          style={{
            height: 44,
            padding: "0 18px",
            borderRadius: 12,
            border: 0,
            background: loading ? "#46506a" : "#7c5cff",
            color: "white",
            fontWeight: 700,
            cursor: loading ? "wait" : "pointer"
          }}
        >
          {loading ? "計算中..." : "計算"}
        </button>
      </form>

      {error ? (
        <div style={{ marginTop: 16, color: "#ffb4b4" }}>{error}</div>
      ) : null}

      {summary ? (
        <>
          <section style={{ display: "flex", flexWrap: "wrap", gap: 12, marginTop: 20 }}>
            <StatCard label="Realized PnL (SOL)" value={fmt(summary.realizedPnlSol, 6)} />
            <StatCard label="Open position" value={fmt(summary.openPositionTokens, 6)} sub="tokens" />
            <StatCard label="Open cost basis (SOL)" value={fmt(summary.openCostBasisSol, 6)} />
            <StatCard label="Analysed txs" value={fmt(summary.analyzedTxCount, 0)} />
          </section>

          <section style={{ marginTop: 22, padding: 18, borderRadius: 18, border: "1px solid rgba(255,255,255,0.12)", background: "rgba(255,255,255,0.03)" }}>
            <h2 style={{ marginTop: 0 }}>Summary</h2>
            <div style={{ display: "grid", gap: 8, lineHeight: 1.6 }}>
              <div>Total bought: {fmt(summary.totalBoughtTokens, 6)}</div>
              <div>Total sold: {fmt(summary.totalSoldTokens, 6)}</div>
              <div>Total buy SOL: {fmt(summary.totalBuySol, 6)}</div>
              <div>Total sell SOL: {fmt(summary.totalSellSol, 6)}</div>
              <div>Reported fees: {fmt(summary.reportedFeesSol, 6)} SOL</div>
            </div>
            {summary.warnings?.length ? (
              <div style={{ marginTop: 12, color: "#ffd37a" }}>
                {summary.warnings.map((w, i) => <div key={i}>{w}</div>)}
              </div>
            ) : null}
          </section>

          <section style={{ marginTop: 22 }}>
            <h2>Trades</h2>
            <div style={{ overflowX: "auto", borderRadius: 16, border: "1px solid rgba(255,255,255,0.12)" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", background: "rgba(255,255,255,0.02)" }}>
                <thead>
                  <tr style={{ textAlign: "left", fontSize: 13, opacity: 0.85 }}>
                    <th style={th}>Time</th>
                    <th style={th}>Type</th>
                    <th style={th}>Token</th>
                    <th style={th}>SOL</th>
                    <th style={th}>Realized PnL</th>
                    <th style={th}>Tx</th>
                  </tr>
                </thead>
                <tbody>
                  {result.trades.map((t) => (
                    <tr key={t.txId} style={{ borderTop: "1px solid rgba(255,255,255,0.08)" }}>
                      <td style={td}>{new Date(t.blockTime * 1000).toLocaleString("ja-JP")}</td>
                      <td style={td}>{t.type}</td>
                      <td style={td}>{fmt(t.tokenAmount, 6)}</td>
                      <td style={td}>{fmt(t.solAmount, 6)}</td>
                      <td style={td}>{t.realizedPnlSol === null ? "-" : fmt(t.realizedPnlSol, 6)}</td>
                      <td style={td}><code style={{ fontSize: 12 }}>{t.txId.slice(0, 10)}…</code></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </>
      ) : null}
    </main>
  );
}

const inputStyle = {
  height: 44,
  borderRadius: 12,
  border: "1px solid rgba(255,255,255,0.14)",
  background: "rgba(255,255,255,0.04)",
  color: "white",
  padding: "0 14px",
  outline: "none"
};

const th = { padding: "12px 14px", borderBottom: "1px solid rgba(255,255,255,0.08)" };
const td = { padding: "12px 14px", verticalAlign: "top" };
